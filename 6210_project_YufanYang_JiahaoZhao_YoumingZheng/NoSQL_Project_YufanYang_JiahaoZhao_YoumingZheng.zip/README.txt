code_collecting_data folder: Contains the code we used to collect, clean, and rearrange data

data_diagrams folder: Contains the data we collected from social medias (Twitter, Facebook, Google)

group_information_6210: Information of the three members on our team

mysql_project � Report: Project report of SQL project, solving the 12 problems with code and explanation

NoSQL_Project_report: Project report of NoSQL project, solving the 12 problems with code and explanation
